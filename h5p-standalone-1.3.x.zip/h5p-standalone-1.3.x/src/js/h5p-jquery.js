H5P = window.H5P || {};
H5P.jQuery = jQuery.noConflict(true);
